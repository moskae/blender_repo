import bpy
import bmesh
import mathutils

# --- CONFIG ---
TUNING_NAMES = ["Stock", "Blaze", "Lizard", "Elite"]

MAT_STRENGTH = {
    "bodyframe": 0.40, "carbon": 0.20, "carbon_forged": 0.25, "chrome_metals": 0.45,
    "enginebay": 0.35, "mesh_hex": 0.00, "mesh_rhomb": 0.05, "metal_plate": 0.30,
    "plastic_gloss": 0.15, "plastic_rough": 0.10, "leather": 0.55, "trims": 0.5,
}

ALLOWED_NAMES = {
    "BlinkerL_lod0", "BlinkerR_lod0", "Body_lod0", "Door1_lod0", "Door2_lod0", "Door3_lod0", "Door4_lod0",
    "Foglight_lod0", "GlassF_lod0", "GlassSL_lod0", "GlassSR_lod0", "Headlight_lod0", "Interior_lod0",
    "Reverse_lod0", "Taillight_lod0", "TaillightM_lod0", "Trunk_lod0", "Body_lod2", "BlinkerL_lod1",
    "BlinkerR_lod1", "Body_lod1", "Door1_lod1", "Door2_lod1", "Door3_lod1", "Door4_lod1", "Foglight_lod1",
    "GlassF_lod1", "GlassSL_lod1", "GlassSR_lod1", "Headlight_lod1", "Interior_lod1", "Reverse_lod1",
    "Taillight_lod1", "TaillightM_lod1", "Trunk_lod1", "BlinkerFL_lod0", "BlinkerFR_lod0", "DiscF_lod0",
    "DiscR_lod0", "Swingarm_lod0", "Body_Stock_lod0", "Exhaust_Stock_lod0", "Exhaust_Blaze_lod0", "ForkL_Stock_lod0", "Taillight_State3_lod0",
    "ForkU_Stock_lod0", "ForkL_Blaze_lod0", "ForkU_Blaze_lod0", "Tail_Stock_lod0", "Tail_Blaze_lod0",
    "BlinkerFL_lod1", "BlinkerFR_lod1", "DiscF_lod1","DiscR_lod1", "Swingarm_lod1", "Body_Stock_lod1",
    "Exhaust_Stock_lod1", "Exhaust_Blaze_lod1", "ForkL_Stock_lod1","ForkU_Stock_lod1", "ForkL_Blaze_lod1",
    "ForkU_Blaze_lod1", "Tail_Stock_lod1", "Tail_Blaze_lod1", "Body_Blaze_lod0", "Body_Blaze_lod1", "Taillight_State3_lod1", "GlassR_lod0", "Hood_lod0", "BlinkerL_BumperF_Stock_lod0", "BlinkerR_BumperF_Stock_lod0", "BlinkerL_BumperF_Blaze_lod0", "BlinkerR_BumperF_Blaze_lod0", "BlinkerL_BumperF_Lizard_lod0", "BlinkerR_BumperF_Lizard_lod0", "BlinkerL_BumperF_Elite_lod0", "BlinkerR_BumperF_Elite_lod0", "BlinkerR_BumperR_Stock_lod0", "BlinkerL_BumperR_Blaze_lod0", "BlinkerR_BumperR_Blaze_lod0", "BlinkerL_BumperR_Lizard_lod0", "BlinkerR_BumperR_Lizard_lod0", "BlinkerL_BumperR_Elite_lod0", "BlinkerR_BumperR_Elite_lod0", "Trunk_Stock_lod0", "Trunk_Blaze_lod0", "Trunk_Lizard_lod0", "Trunk_Elite_lod0", "GlassR_lod1", "Hood_lod1", "BlinkerL_BumperF_Stock_lod1", "BlinkerR_BumperF_Stock_lod1", "BlinkerL_BumperF_Blaze_lod1", "BlinkerR_BumperF_Blaze_lod1", "BlinkerL_BumperF_Lizard_lod1", "BlinkerR_BumperF_Lizard_lod1", "BlinkerL_BumperF_Elite_lod1", "BlinkerR_BumperF_Elite_lod1", "BlinkerR_BumperR_Stock_lod1", "BlinkerL_BumperR_Blaze_lod1", "BlinkerR_BumperR_Blaze_lod1", "BlinkerL_BumperR_Lizard_lod1", "BlinkerR_BumperR_Lizard_lod1", "BlinkerL_BumperR_Elite_lod1", "BlinkerR_BumperR_Elite_lod1", "Trunk_Stock_lod1", "Trunk_Blaze_lod1", "Trunk_Lizard_lod1", "Trunk_Elite_lod1", "Wheel_FL", "Wheel_FR", "Wheel_RR", "Wheel_RL"
}
for t in ["Stock", "Blaze", "Lizard", "Elite"]:
    for lod in ["lod0", "lod1"]:
        for part in ["BumperF", "BumperR", "Foglight_BumperF", "Hood", "Skirts", "Spoiler"]:
            ALLOWED_NAMES.add(f"{part}_{t}_{lod}")

# --- ALLOWED MATERIALS ---
ALLOWED_MATS_STATIC = set(MAT_STRENGTH.keys()) | {"body_paint", "glass", "glass_cover", "texture_array"}

def is_mat_allowed(mat_name):
    if mat_name in ALLOWED_MATS_STATIC:
        return True
    if mat_name.endswith("_lights") or mat_name.endswith("_detail"):
        return True
    return False

# --- HELPERS ---
def get_closest_mat(val):
    closest = None
    min_diff = 10.0
    for name, m_val in MAT_STRENGTH.items():
        diff = abs(val - m_val)
        if diff < min_diff:
            min_diff = diff
            closest = name
    return closest

def get_or_create_coll(name, parent=None):
    col = bpy.data.collections.get(name)
    if not col:
        col = bpy.data.collections.new(name)
        try:
            if parent: parent.children.link(col)
            else: bpy.context.scene.collection.children.link(col)
        except RuntimeError:
            pass
    return col

# --- OPERATORS ---

class VEHICLE_OT_CleanAttributes(bpy.types.Operator):
    bl_idname = "vehicle.clean_attributes"
    bl_label = "Clean Attributes"
    bl_description = "Clean Color attribute and UV maps"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            mesh = obj.data

           # --- 1. Очистка и переименование UV ---
            active_uv = mesh.uv_layers.active

            if active_uv:
                # Переименовываем активный канал, сохраняя все его данные
                active_uv.name = "UVMap"

                # Собираем имена остальных каналов для безопасного удаления
                uv_to_remove = [uv.name for uv in mesh.uv_layers if uv != active_uv]
                for name in uv_to_remove:
                    layer = mesh.uv_layers.get(name)
                    if layer:
                        mesh.uv_layers.remove(layer)
            else:
                # Если у объекта вообще не было UV-карт, создаем дефолтную
                mesh.uv_layers.new(name="UVMap")

            # --- 2. Очистка и создание Color Attributes ---
            # Используем color_attributes для удаления только цветов
            ca_names = [ca.name for ca in mesh.color_attributes]
            for name in ca_names:
                ca = mesh.color_attributes.get(name)
                if ca:
                    mesh.color_attributes.remove(ca)

            # Создаем новый атрибут цвета
            # BYTE_COLOR + CORNER
            new_attr = mesh.color_attributes.new(
                name="Col",
                type='BYTE_COLOR',
                domain='CORNER'
            )

            # Установка активным для вьюпорта и рендера
            idx = mesh.color_attributes.find(new_attr.name)
            mesh.color_attributes.active_color_index = idx
            mesh.color_attributes.render_color_index = idx

        # Принудительное обновление интерфейса
        if context.area:
            context.area.tag_redraw()

        return {'FINISHED'}

class VEHICLE_OT_CleanNgons(bpy.types.Operator):
    bl_idname = "vehicle.clean_ngons"
    bl_label = "Clean N-Gons"
    bl_description = "Clean N-Gons"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type != 'MESH': continue
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            ngons = [f for f in bm.faces if len(f.verts) > 4]
            if ngons: bmesh.ops.triangulate(bm, faces=ngons)
            bm.to_mesh(obj.data)
            bm.free()
        return {'FINISHED'}

class VEHICLE_OT_MirrorX(bpy.types.Operator):
    bl_idname = "vehicle.mirror_x"
    bl_label = "Mirror X"
    bl_description = "Mirror object by X axis"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        sel = context.selected_objects[:]
        for obj in sel:
            if obj.type != 'MESH': continue

            # Чистим зеркало у оригинала
            for m in [m for m in obj.modifiers if m.type == 'MIRROR']:
                obj.modifiers.remove(m)

            # Нейминг
            replaces = {"L_": "R_","R_": "L_", "1_": "2_", "3_": "4_", "2_": "1_", "4_": "3_"}
            new_name = obj.name
            for k, v in replaces.items():
                if k in obj.name:
                    new_name = obj.name.replace(k, v); break
            if new_name == obj.name: new_name += "_mir"

            # Дубликат
            new_obj = obj.copy()
            new_obj.data = obj.data.copy()
            new_obj.name = new_name
            for col in obj.users_collection: col.objects.link(new_obj)

            # Отражение и Нормали
            new_obj.matrix_world = mathutils.Matrix.Scale(-1, 4, (1, 0, 0)) @ obj.matrix_world
            bm = bmesh.new(); bm.from_mesh(new_obj.data)
            bmesh.ops.reverse_faces(bm, faces=bm.faces)
            bm.to_mesh(new_obj.data); bm.free()

            context.view_layer.objects.active = new_obj
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        return {'FINISHED'}

class VEHICLE_OT_MatsCheck(bpy.types.Operator):
    bl_idname = "vehicle.mats_check"
    bl_label = "Materials Check"
    bl_description = "Check for empty or disallowed materials on selected meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objs = [obj for obj in context.selected_objects if obj.type == 'MESH']

        if not selected_objs:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}

        has_issues = False

        for obj in selected_objs:
            context.view_layer.objects.active = obj

            # Проверка на пустые материалы, нанесенные на полигоны
            has_empty_assigned = any(
                p.material_index < len(obj.material_slots) and obj.material_slots[p.material_index].material is None
                for p in obj.data.polygons
            )

            if has_empty_assigned:
                self.report({'ERROR'}, f"'{obj.name}' has empty material assigned to polygons")
                has_issues = True

            # Проверка на недопустимые материалы
            disallowed = set()
            for slot in obj.material_slots:
                mat = slot.material
                if mat and not is_mat_allowed(mat.name):
                    disallowed.add(mat.name)

            if disallowed:
                self.report({'ERROR'}, f"'{obj.name}' has disallowed materials: {', '.join(sorted(disallowed))}")
                has_issues = True

        if not has_issues:
            self.report({'INFO'}, "All materials are valid")

        return {'FINISHED' if not has_issues else 'CANCELLED'}


class VEHICLE_OT_Bake(bpy.types.Operator):
    bl_idname = "vehicle.bake_materials"
    bl_label = "Apply Texture Array"
    bl_description = "Apply texture array and save materials to red channel"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        t_name = "texture_array"
        t_mat = bpy.data.materials.get(t_name) or bpy.data.materials.new(t_name)

        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            # Делаем объект активным для работы с материалами
            context.view_layer.objects.active = obj

            # Удаляем пустые слоты, которые не нанесены ни на один полигон
            bpy.ops.object.material_slot_remove_unused()

            obj_materials = [slot.material for slot in obj.material_slots]

            # Проверяем, есть ли вообще полигоны с материалами из MAT_STRENGTH
            has_mat_strength_faces = False
            for f in obj.data.polygons:
                if f.material_index < len(obj_materials):
                    slot_mat = obj_materials[f.material_index]
                    if slot_mat and slot_mat.name in MAT_STRENGTH:
                        has_mat_strength_faces = True
                        break

            # Если нет ни одного полигона с материалом из MAT_STRENGTH — пропускаем объект
            if not has_mat_strength_faces:
                continue

            # === ШАГ 1: Бейкинг материалов в вертексный цвет ===
            if not obj.data.attributes.get("Col"):
                obj.data.attributes.new(name="Col", type='FLOAT_COLOR', domain='CORNER')

            bm = bmesh.new()
            bm.from_mesh(obj.data)
            col_lay = bm.loops.layers.color.get("Col")

            if t_name not in obj.data.materials[:]:
                obj.data.materials.append(t_mat)
            t_idx = obj.data.materials.find(t_name)

            for f in bm.faces:
                if f.material_index >= len(obj_materials):
                    continue

                slot_mat = obj_materials[f.material_index]
                if slot_mat and slot_mat.name in MAT_STRENGTH:
                    val = MAT_STRENGTH[slot_mat.name]
                    for l in f.loops:
                        current_col = l[col_lay]
                        l[col_lay] = (val, current_col[1], current_col[2], current_col[3])

                    f.material_index = t_idx

            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()

            # === ШАГ 2: Удаляем только материалы из MAT_STRENGTH ===
            context.view_layer.objects.active = obj
            for i in range(len(obj.material_slots) - 1, -1, -1):
                mat = obj.material_slots[i].material
                if mat and mat.name in MAT_STRENGTH:
                    obj.active_material_index = i
                    bpy.ops.object.material_slot_remove()

        return {'FINISHED'}


class VEHICLE_OT_Revert(bpy.types.Operator):
    bl_idname = "vehicle.revert_materials"
    bl_label = "Revert Materials"
    bl_description = "Revert materials from array"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Гарантируем наличие всех материалов в сцене заранее (один раз)
        for mat_name in MAT_STRENGTH:
            if mat_name not in bpy.data.materials:
                bpy.data.materials.new(mat_name)

        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            t_idx = obj.data.materials.find("texture_array")
            if t_idx == -1:
                continue

            bm = bmesh.new()
            bm.from_mesh(obj.data)
            col_lay = bm.loops.layers.color.get("Col")

            if col_lay:
                # Добавляем отсутствующие материалы в объект
                for mat_name in MAT_STRENGTH:
                    if mat_name not in obj.data.materials[:]:
                        obj.data.materials.append(bpy.data.materials[mat_name])

                for f in bm.faces:
                    if f.material_index == t_idx:

                        # ИСПРАВЛЕНИЕ: Берем строго значение [0] (красный канал) из каждой вершины петли
                        red_sum = 0.0
                        for l in f.loops:
                            red_sum += l[col_lay][0]  # <--- Добавлен индекс [0]

                        avg_red = red_sum / len(f.loops) if len(f.loops) > 0 else 0.0

                        # Теперь get_closest_mat получит чистое число с плавающей точкой
                        m_name = get_closest_mat(avg_red)
                        if m_name:
                            f.material_index = obj.data.materials.find(m_name)

            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()

        # Очистка неиспользуемых слотов
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                context.view_layer.objects.active = obj
                bpy.ops.object.material_slot_remove_unused()

        return {'FINISHED'}

class VEHICLE_OT_CopyTo(bpy.types.Operator):
    bl_idname = "vehicle.copy_to"
    bl_label = "Copy to Tuning"
    bl_description = "Copy selected meshes to collection and rename"
    bl_options = {'REGISTER', 'UNDO'}
    target: bpy.props.StringProperty()

    def execute(self, context):
        dest = get_or_create_coll(self.target)
        for obj in context.selected_objects:
            new_obj = obj.copy(); new_obj.data = obj.data.copy()
            new_name = obj.name
            for t in TUNING_NAMES:
                if f"_{t}_" in obj.name:
                    new_name = obj.name.replace(f"_{t}_", f"_{self.target}_")
                    break
            else: new_name = obj.name.replace("_lod", f"_{self.target}_lod")
            new_obj.name = new_name
            dest.objects.link(new_obj)
        return {'FINISHED'}

class VEHICLE_OT_Sort(bpy.types.Operator):
    bl_idname = "vehicle.sort_fbx"
    bl_label = "Sort FBX"
    bl_description = "Make base ierarchy and sort objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        root = context.scene.collection
        selected_objs = [obj for obj in context.selected_objects if obj.type == 'MESH']

        if not selected_objs:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}

        # 1. Создаем основные папки LOD в нужном порядке
        lods = {l: get_or_create_coll(l, root) for l in ["lod0", "lod1", "lod2"]}

        # 2. Создаем подколлекции: сначала Main, потом Тюнинг
        subs = {"lod0": {}, "lod1": {}}

        for lk in ["lod0", "lod1"]:
            parent_c = lods[lk]

            # ПЕРВОЙ создаем Main
            m_name = "Main" if lk == "lod0" else f"Main_{lk}"
            subs[lk]["main"] = get_or_create_coll(m_name, parent_c)

            # ЗАТЕМ создаем тюнинги по списку TUNING_NAMES
            for t in TUNING_NAMES:
                tk = t.lower()
                t_name = t.capitalize() if lk == "lod0" else f"{t.capitalize()}_{lk}"
                subs[lk][tk] = get_or_create_coll(t_name, parent_c)

        # 3. Раскидываем объекты
        for obj in selected_objs:
            n = obj.name.lower()

            # Логика определения цели
            if "lod2" in n:
                target = lods["lod2"]
            else:
                lk = "lod1" if "lod1" in n else "lod0"
                t_key = "main"
                for t in TUNING_NAMES:
                    if t.lower() in n:
                        t_key = t.lower()
                        break
                target = subs[lk][t_key]

            # Перемещение
            if obj.name not in target.objects:
                target.objects.link(obj)
            for col in list(obj.users_collection):
                if col != target:
                    col.objects.unlink(obj)

        return {'FINISHED'}

class VEHICLE_OT_CheckNames(bpy.types.Operator):
    bl_idname = "vehicle.check_names"
    bl_label = "Check Mesh Names"
    bl_description = "Check Mesh Names"

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.name in ALLOWED_NAMES:
                obj.select_set(False)
            else:
                self.report({'WARNING'}, f"'{obj.name}' is not in the allowed names list")
        return {'FINISHED'}

class VEHICLE_OT_PrepareTemplates(bpy.types.Operator):
    bl_idname = "vehicle.prepare_templates"
    bl_label = "Paint Templates"
    bl_description = "Make Template collection for export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Очистка старой коллекции Template, если она есть
        old_coll = bpy.data.collections.get("Template")
        if old_coll:
            for obj in old_coll.objects:
                bpy.data.objects.remove(obj, do_unlink=True)

        template_coll = get_or_create_coll("Template")
        main_coll = bpy.data.collections.get("Main")

        if not main_coll:
            self.report({'ERROR'}, "Collection 'Main' not found!")
            return {'CANCELLED'}

        for t_name in TUNING_NAMES:
            tuning_coll = bpy.data.collections.get(t_name)
            if not tuning_coll: continue

            # Сбор и копирование
            to_join = []
            source_objs = list(main_coll.objects) + list(tuning_coll.objects)

            for obj in source_objs:
                if obj.type != 'MESH': continue
                new_obj = obj.copy()
                new_obj.data = obj.data.copy()
                template_coll.objects.link(new_obj)
                to_join.append(new_obj)

            if not to_join: continue

            # Объединение
            bpy.ops.object.select_all(action='DESELECT')
            for o in to_join: o.select_set(True)
            context.view_layer.objects.active = to_join[0]
            bpy.ops.object.join()

            merged = context.active_object
            merged.name = t_name

            # Отделение body_paint
            paint_idx = merged.data.materials.find("body_paint")
            if paint_idx != -1:
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='DESELECT')
                merged.active_material_index = paint_idx
                bpy.ops.object.material_slot_select()

                # Проверка, есть ли выделенные полигоны
                bm = bmesh.from_edit_mesh(merged.data)
                selected_faces = [f for f in bm.faces if f.select]

                if selected_faces:
                    bpy.ops.mesh.separate(type='SELECTED')
                    bpy.ops.object.mode_set(mode='OBJECT')

                    # Переименование
                    objects_after = context.selected_objects
                    for p in objects_after:
                        if p != merged:
                            p.name = f"{t_name}_u"
                        else:
                            p.name = t_name
                else:
                    bpy.ops.object.mode_set(mode='OBJECT')

        self.report({'INFO'}, "Templates generated in 'Template' collection")
        return {'FINISHED'}

class VEHICLE_OT_ApplyMirror(bpy.types.Operator):
    bl_idname = "vehicle.apply_mirror"
    bl_label = "Apply Mirror"
    bl_description = "Apply only Mirror modifiers for selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = 0
        selected = context.selected_objects[:]

        for obj in selected:
            if obj.type != 'MESH':
                continue

            # Находим все модификаторы зеркала
            mirrors = [m for m in obj.modifiers if m.type == 'MIRROR']

            if not mirrors:
                continue

            # Делаем объект активным, так как оператор применения работает с активным
            context.view_layer.objects.active = obj

            for m in mirrors:
                try:
                    # Применяем модификатор по имени
                    bpy.ops.object.modifier_apply(modifier=m.name)
                    count += 1
                except Exception as e:
                    self.report({'ERROR'}, f"Could not apply mirror on {obj.name}: {e}")

        if count > 0:
            self.report({'INFO'}, f"Applied {count} Mirror modifiers")
        else:
            self.report({'WARNING'}, "No Mirror modifiers found")

        return {'FINISHED'}

class VEHICLE_OT_LrsCheck(bpy.types.Operator):
    bl_idname = "vehicle.lrs_check"
    bl_label = "Transform Check"
    bl_description = "Check if transforms are correct"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objs = context.selected_objects[:]

        if not selected_objs:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        non_compliant_count = 0

        # Список ключевых слов в названии объектов, для которых НЕ нужно проверять Location
        loc_exceptions = ["door", "wheel", "Wheel_FL", "Wheel_FR", "Wheel_RR", "Wheel_RL"]

        # Список объектов, для которых НЕ нужно проверять Scale
        scale_exceptions = ["Wheel_FL", "Wheel_FR", "Wheel_RR", "Wheel_RL"]

        print("\n--- LRS CHECK REPORT ---")

        for obj in selected_objs:
            issues = []
            obj_name_lower = obj.name.lower()

            # 1. Прямая проверка Location (только если в имени НЕТ исключений)
            # Проверяем, содержит ли имя хотя бы одно слово из списка исключений
            has_loc_exception = any(exc in obj_name_lower for exc in loc_exceptions)

            if not has_loc_exception:
                if obj.location.x != 0.0 or obj.location.y != 0.0 or obj.location.z != 0.0:
                    issues.append("location not equal 0")

            # 2. Прямая проверка Rotation (выполняется для ВСЕХ объектов)
            if obj.rotation_euler.x != 0.0 or obj.rotation_euler.y != 0.0 or obj.rotation_euler.z != 0.0:
                issues.append("rotation not equal 0")

            # 3. Прямая проверка Scale (только если в имени НЕТ исключений)
            has_scale_exception = any(exc in obj.name for exc in scale_exceptions)

            if not has_scale_exception:
                if obj.scale.x != 1.0 or obj.scale.y != 1.0 or obj.scale.z != 1.0:
                    issues.append("scale not equal 1")

            # Анализ результатов
            if issues:
                non_compliant_count += 1
                report_msg = f"{obj.name}: {', '.join(issues)}"

                print(report_msg)
                self.report({'WARNING'}, report_msg)

                obj.select_set(True)  # Оставляем выделенным
            else:
                obj.select_set(False) # Снимаем выделение

        print("------------------------\n")

        if non_compliant_count == 0:
            self.report({'INFO'}, "All selected objects have correct transforms!")

        return {'FINISHED'}

class VEHICLE_OT_LodsCheck(bpy.types.Operator):
    bl_idname = "vehicle.lods_check"
    bl_label = "LODs Objects Check"
    bl_description = "Check lods objects)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objs = context.selected_objects[:]

        if not selected_objs:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        # Словари для хранения объектов по их базовым именам
        lod0_dict = {}
        lod1_dict = {}

        # Объекты, которые вообще не относятся к lod0/lod1 (их просто снимем с выделения)
        other_objs = []

        # Разносим объекты по группам
        for obj in selected_objs:
            if obj.name.endswith("_lod0"):
                base_name = obj.name[:-5]  # Отрезаем "_lod0"
                lod0_dict[base_name] = obj
            elif obj.name.endswith("_lod1"):
                base_name = obj.name[:-5]  # Отрезаем "_lod1"
                lod1_dict[base_name] = obj
            else:
                other_objs.append(obj)

        missing_count = 0
        print("\n--- LODS CHECK REPORT ---")

        # Проверяем, для каких lod0 нет пары lod1
        for base_name, obj in lod0_dict.items():
            if base_name not in lod1_dict:
                missing_count += 1
                report_msg = f"Missing pair: {obj.name} (has no _lod1)"
                print(report_msg)
                self.report({'WARNING'}, report_msg)
                obj.select_set(True)  # Оставляем выделенным
            else:
                obj.select_set(False) # Пара есть — снимаем выделение

        # Проверяем, для каких lod1 нет пары lod0
        for base_name, obj in lod1_dict.items():
            if base_name not in lod0_dict:
                missing_count += 1
                report_msg = f"Missing pair: {obj.name} (has no _lod0)"
                print(report_msg)
                self.report({'WARNING'}, report_msg)
                obj.select_set(True)  # Оставляем выделенным
            else:
                # Если у него есть пара, она уже обработалась или снимется здесь
                lod0_dict[base_name].select_set(False)
                obj.select_set(False)

        # Снимаем выделение со всех остальных объектов, которые не lod0/lod1
        for obj in other_objs:
            obj.select_set(False)

        # --- Проверка симметрии (захардкоженные пары) ---
        sym_bases = ["BlinkerL", "Door1", "Door3", "GlassSL", "BlinkerFL"]
        sym_counterpart = {"BlinkerL": "BlinkerR", "Door1": "Door2", "Door3": "Door4", "GlassSL": "GlassSR", "BlinkerFL": "BlinkerFR"}
        names = {obj.name for obj in selected_objs}

        for lod in ["lod0", "lod1"]:
            for base in sym_bases:
                left = f"{base}_{lod}"
                right = f"{sym_counterpart[base]}_{lod}"
                has_left = left in names
                has_right = right in names
                if has_left and not has_right:
                    missing_count += 1
                    report_msg = f"Missing symmetry: {left} (no {right})"
                    print(report_msg)
                    self.report({'WARNING'}, report_msg)
                elif has_right and not has_left:
                    missing_count += 1
                    report_msg = f"Missing symmetry: {right} (no {left})"
                    print(report_msg)
                    self.report({'WARNING'}, report_msg)

        print("------------------------\n")

        if missing_count == 0:
            self.report({'INFO'}, "All selected LODs match perfectly!")

        return {'FINISHED'}

# --- UI ---

class VEHICLE_PT_Panel(bpy.types.Panel):
    bl_label = "Vehicle Tool 🚗 2.8.1"
    bl_idname = "VEHICLE_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Vehicle Tool'

    def draw(self, context):
        layout = self.layout
        col = layout.column()

        # Группа 1: Copy To как выпадающее меню с кнопками из TUNING_NAMES
        row = col.row(align=True)
        row.menu("VEHICLE_MT_CopyToMenu", text="Copy To", icon='COPYDOWN')

        # Кнопка Sort FBX
        col.operator("vehicle.sort_fbx", icon='FILE_FOLDER')

        col.separator(factor=0.5)

        col.separator(factor=0.5)

        # Группа 3: Mirror
        col.operator("vehicle.mirror_x", icon='MOD_MIRROR')
        col.operator("vehicle.apply_mirror", icon='MODIFIER')

        col.separator(factor=0.5)

        # Группа 4: Материалы
        col.operator("vehicle.bake_materials", icon='IMAGE_DATA')
        col.operator("vehicle.revert_materials", icon='NODE_MATERIAL')

        #Группа 5: Шаблон для покраски
        col.separator(factor=0.5)
        col.operator("vehicle.prepare_templates", icon='BRUSH_DATA')

        # Группа 6: Проверки и очистка
class VEHICLE_PT_SubChecks(bpy.types.Panel):
    bl_label = "Checks & Clean"
    bl_idname = "VEHICLE_PT_sub_checks"
    bl_parent_id = "VEHICLE_PT_main_panel" # Привязка к главной панели
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column()

        col.operator("vehicle.check_names", icon='CHECKMARK')
        col.operator("vehicle.clean_attributes", icon='TRASH')
        col.operator("vehicle.clean_ngons", icon='MESH_DATA')
        col.operator("vehicle.lrs_check", icon='SNAP_VOLUME')
        col.operator("vehicle.lods_check", icon='COMMUNITY')
        col.operator("vehicle.mats_check", icon='MATERIAL')


# Класс меню для выпадающего списка Copy To
class VEHICLE_MT_CopyToMenu(bpy.types.Menu):
    bl_label = "Copy To"
    bl_idname = "VEHICLE_MT_CopyToMenu"

    def draw(self, context):
        layout = self.layout

        # Берем названия из TUNING_NAMES
        for tuning_name in TUNING_NAMES:
            op = layout.operator("vehicle.copy_to", text=tuning_name)
            op.target = tuning_name


# --- REGISTRATION ---
# Добавляем класс меню
classes = [
    VEHICLE_OT_CleanAttributes, VEHICLE_OT_CleanNgons, VEHICLE_OT_MirrorX,
    VEHICLE_OT_Bake, VEHICLE_OT_Revert, VEHICLE_OT_CopyTo,
    VEHICLE_OT_Sort, VEHICLE_OT_CheckNames, VEHICLE_PT_Panel,
    VEHICLE_OT_PrepareTemplates, VEHICLE_OT_ApplyMirror,
    VEHICLE_MT_CopyToMenu, VEHICLE_OT_LrsCheck, VEHICLE_OT_LodsCheck, VEHICLE_OT_MatsCheck,
    VEHICLE_PT_SubChecks
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.vehicle_tuning_list = bpy.props.EnumProperty(
        items=[(n, n, "") for n in TUNING_NAMES],
        default='Stock'
    )

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    if hasattr(bpy.types.Scene, "vehicle_tuning_list"):
        del bpy.types.Scene.vehicle_tuning_list

if __name__ == "__main__":
    register()
#Нечего тебе тут делать, этот прекрасный говнокод делает все, что нужно!
